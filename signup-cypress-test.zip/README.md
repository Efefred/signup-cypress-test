# signup-cypress-test
A quick test to confirm that my project is fine.
